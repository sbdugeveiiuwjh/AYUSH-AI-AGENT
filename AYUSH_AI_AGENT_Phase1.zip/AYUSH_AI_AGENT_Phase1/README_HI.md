# AYUSH AI AGENT — Phase 1 Prototype

यह Android Studio का शुरुआती native Kotlin + Jetpack Compose प्रोजेक्ट है।

## Phase 1 में क्या काम करता है?
- Dark blue/purple assistant UI और animated AI orb
- Mic दबाने पर Android speech recognition
- Hindi (hi-IN) voice recognition preference
- बोले गए शब्द स्क्रीन पर दिखते हैं
- Android Text-to-Speech से जवाब बोलता है
- Local in-memory command history
- Settings/Privacy जानकारी और Stop button

## अभी क्या नहीं है?
- Gemini API अभी जुड़ी नहीं है
- Instagram/YouTube खोलना अभी implement नहीं है
- Call/WhatsApp/Accessibility automation अभी implement नहीं है
- यह तैयार APK नहीं है; Android Studio से build करना होगा

## Build करने के चरण
1. Computer पर Android Studio का current stable version install करें.
2. इस ZIP को extract करें.
3. Android Studio में `AYUSH_AI_AGENT` folder खोलें.
4. Gradle sync पूरा होने दें; पहली बार internet से Android dependencies डाउनलोड होंगी.
5. Android phone में Developer options और USB debugging enable करके USB से connect करें, या Android Emulator चुनें.
6. Run ▶ दबाएँ.
7. पहली बार `Talk to AI` दबाने पर microphone permission दें.

## जरूरी नोट
- `SpeechRecognizer` device की उपलब्ध speech service का उपयोग करता है; इंटरनेट/भाषा सपोर्ट फोन पर निर्भर कर सकता है.
- यह Phase 1 prototype है, पूरा phone-control agent नहीं.
- Gemini API key को Android app में hard-code न करें. Phase 2 में secure backend से जोड़ें.
