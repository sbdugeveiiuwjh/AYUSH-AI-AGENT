package com.ayush.aiagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Night = Color(0xFF080B18)
private val Panel = Color(0xFF141A2E)
private val Cyan = Color(0xFF59D8FF)
private val Violet = Color(0xFF9A72FF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var onResult: ((String) -> Unit)? = null
    private var onError: (() -> Unit)? = null
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startListeningInternal() else onError?.invoke()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Night, surface = Panel, primary = Cyan,
                secondary = Violet, onBackground = Color.White, onSurface = Color.White
            )) {
                AgentHome(
                    speak = { say(it) },
                    listen = { result, error ->
                        onResult = result; onError = error
                        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            startListeningInternal()
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    stop = { speechRecognizer?.cancel(); say("Listening stopped.") }
                )
            }
        }
    }

    private fun startListeningInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { onError?.invoke(); return }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { onError?.invoke() }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text != null) onResult?.invoke(text) else onError?.invoke()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "AYUSH AI AGENT is listening…")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ayush-agent")
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
    }
    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun AgentHome(speak: (String) -> Unit, listen: ((String) -> Unit, () -> Unit) -> Unit, stop: () -> Unit) {
    var heard by remember { mutableStateOf("Aapka personal AI assistant") }
    var response by remember { mutableStateOf("Namaste! Mic dabakar apna command boliye.") }
    var status by remember { mutableStateOf("READY") }
    var selectedTab by remember { mutableStateOf(0) }
    val history = remember { mutableStateListOf<String>() }
    val pulse by rememberInfiniteTransition(label = "orb").animateFloat(
        initialValue = 0.96f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pulse"
    )

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111A36), Night, Color(0xFF100B25))))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("AYUSH", fontSize = 13.sp, color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                    Text("AI AGENT", fontSize = 25.sp, color = Color.White, fontWeight = FontWeight.ExtraBold)
                }
                IconButton(onClick = { selectedTab = 2 }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
                IconButton(onClick = { selectedTab = 1 }) { Icon(Icons.Default.History, "History", tint = Color.White) }
            }
            Spacer(Modifier.height(16.dp))
            when (selectedTab) {
                1 -> {
                    Text("COMMAND HISTORY", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    if (history.isEmpty()) Text("Abhi koi command nahi hai.", color = Color.LightGray)
                    LazyColumn(Modifier.weight(1f)) {
                        items(history.reversed()) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                                Text(item, Modifier.padding(14.dp), color = Color.White)
                            }
                        }
                    }
                    OutlinedButton(onClick = { history.clear() }, modifier = Modifier.fillMaxWidth()) { Text("Clear history") }
                }
                2 -> {
                    Text("SETTINGS & PRIVACY", color = Cyan, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    InfoCard("Microphone", "Voice commands ke liye permission tabhi maangi jayegi jab aap mic dabayenge.")
                    InfoCard("Gemini AI", "Phase 1 mein Gemini connect nahi hai. Phase 2 mein secure backend ke through jodega.")
                    InfoCard("Phone control", "Abhi sirf voice recognition aur UI prototype. App opening/calling agle phase mein aayega.")
                    InfoCard("Privacy", "Voice recognition Android ki speech service use karta hai; device/service ke hisaab se audio processing ho sakti hai.")
                    Spacer(Modifier.weight(1f))
                    Button(onClick = { selectedTab = 0 }, modifier = Modifier.fillMaxWidth()) { Text("Back to assistant") }
                }
                else -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).background(if (status == "LISTENING") Cyan else Color(0xFF52E0A0), CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(status, color = if (status == "LISTENING") Cyan else Color(0xFFB6C3E2), fontSize = 12.sp, letterSpacing = 2.sp)
                    }
                    Spacer(Modifier.height(24.dp))
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(210.dp).scale(pulse)
                                .background(Brush.radialGradient(listOf(Color(0xFF526CFF), Color(0xFF713FE5), Color.Transparent)), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(Modifier.size(135.dp).background(Brush.linearGradient(listOf(Cyan, Violet)), CircleShape), contentAlignment = Alignment.Center) {
                                Text("AI", color = Color.White, fontSize = 43.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                    Text(heard, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(10.dp))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("AYUSH AI", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(response, color = Color(0xFFE1E7FF), fontSize = 15.sp)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = {
                                status = "LISTENING"
                                response = "Sun raha hoon…"
                                listen({ text ->
                                    heard = "“$text”"
                                    status = "RECEIVED"
                                    val reply = "Aapne kaha: $text. Abhi Phase 1 mein main command sun sakta hoon; phone actions aur Gemini integration agle phases mein judenge."
                                    response = reply
                                    history.add("You: $text\nAI: $reply")
                                    speak(reply)
                                }, {
                                    status = "READY"
                                    response = "Awaaz nahi mili ya permission nahi di gayi. Dobara try karein."
                                })
                            },
                            modifier = Modifier.weight(1f).height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3157D5))
                        ) {
                            Icon(Icons.Default.Mic, null); Spacer(Modifier.width(8.dp)); Text("Talk to AI")
                        }
                        OutlinedButton(onClick = { stop(); status = "STOPPED"; response = "Listening band kar diya." }, modifier = Modifier.height(56.dp)) {
                            Icon(Icons.Default.Stop, null); Spacer(Modifier.width(4.dp)); Text("Stop")
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("TRY: “Instagram kholo” • “YouTube kholo” • “Shubham ko call karo”", color = Color(0xFF8998C2), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, description: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(description, color = Color(0xFFD3DAF0), fontSize = 13.sp)
        }
    }
}
